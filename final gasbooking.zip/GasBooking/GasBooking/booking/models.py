from django.db import models

# Create your models here.

class Registration(models.Model):
    name = models.CharField(max_length=70)
    email = models.CharField(max_length=120, primary_key=True)
    mobile = models.CharField(max_length=10)
    password = models.CharField(max_length=15)

    def __str__(self):
        return self.email


class Status(models.Model):
    status = models.CharField(max_length=20)

    def __str__(self):
        return self.status


class Connection(models.Model):
    name = models.CharField(max_length=70)
    email = models.CharField(max_length=120,primary_key=True)
    mobile = models.CharField(max_length=10)
    gender = models.CharField(max_length=6)
    dob = models.CharField(max_length=10)
    father_name = models.CharField(max_length=70)
    nationality = models.CharField(max_length=12)
    add = models.CharField(max_length=70)
    city = models.CharField(max_length=20)
    type = models.CharField(max_length=15)
    pincode = models.IntegerField()
    photo = models.ImageField(upload_to='profile')
    conn_date = models.DateTimeField(auto_now=True)
    status = models.ForeignKey(Status ,on_delete=models.CASCADE)



    def __str__(self):
        return "%s %s" % (self.status,self.email)

class Price(models.Model):
    id = models.AutoField(primary_key=True)
    cylinderType = models.CharField(max_length=30)
    price = models.IntegerField()

    def __str__(self):
        return self.cylinderType


class Booking(models.Model):
    id = models.AutoField(primary_key=True)
    email = models.CharField(max_length=120)
    name = models.CharField(max_length=50)
    b_date = models.CharField(max_length=12)
    d_date = models.CharField(max_length=12)
    ctype = models.CharField(max_length=15)
    price = models.IntegerField()
    status = models.ForeignKey(Status,  on_delete=models.CASCADE)

    def __str__(self):
        return "%s %s" % (self.status,self.email)


class SubOffice(models.Model):
    name = models.CharField( max_length=50)
    email = models.CharField( max_length=120)
    phone = models.CharField( max_length=10)
    add  = models.CharField(max_length=100)
    city  = models.CharField( max_length=50)
    pincode = models.CharField(max_length=6)


    def __str__(self):
        return self.name