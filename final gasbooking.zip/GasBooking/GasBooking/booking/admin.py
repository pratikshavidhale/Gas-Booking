from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Registration)
admin.site.register(Connection)
admin.site.register(Price)
admin.site.register(Booking)
admin.site.register(Status)
admin.site.register(SubOffice)