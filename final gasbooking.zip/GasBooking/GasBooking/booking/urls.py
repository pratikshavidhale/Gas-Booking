from django.urls import path
from . import views
from django.contrib import admin

admin.site.site_header = "Gas Booking"
admin.site.site_title = "Welcome to Admin Dashboard"
admin.site.index_title="Abhishek"
urlpatterns = [
    path("", views.index),
    path("login/", views.login, name="Login"),
    path("register/", views.register,name="Registration"),
    path('customer/home/', views.customerhome, name="Customer Name"),
    path('customer/newconnection/', views.newconnection, name="New Connection"),
    path('logout/', views.logout, name="Logout"),
    path('customer/profile/', views.profile, name="Profile"),
    path('profileupdate/', views.profileupdate, name="Profile Update"),
    path('customer/book/', views.booking, name="Book"),
    path('customer/editorder/<str:pk>/',views.editorder, name="editorder"),
]
