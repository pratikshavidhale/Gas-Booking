from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponseRedirect
from .models import *
from datetime import date 
import datetime
from django.conf import settings
from django.core.files.storage import FileSystemStorage
# Create your views here.

def index(request):
    return render(request, 'index.html')


def login(request):
    if request.method == 'POST':
        email = request.POST.get('username')
        password = request.POST.get('password')
        user = Registration.objects.get(email = email)
        if user.password == password:
            request.session['user'] = email
            return redirect(customerhome)
    return render(request, 'index.html')

def register(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')
        password = request.POST.get('password')
        print(name,email,mobile,password)
        emailCheck = Registration.objects.filter(email = email)
        if emailCheck :
            msg = "Email Id all ready exist!!! please Login"
            return render(request, 'registration.html', {'msg':msg})
        else:
            create = Registration(name, email, mobile, password)
            create.save()
            return redirect(login)
    return render(request, 'registration.html')


def customerhome(request):
    if request.session.has_key('user'):
        e = request.session['user']
        isconn = Connection.objects.filter(email =e)
        # if isconn:
        #     near  = Connection.objects.get(email = e)
        #     pin = near.pincode
        #     suboffice = SubOffice.objects.filter(pincode = pin)
        #     sub = {}
        #     if suboffice:
        #         suboffice = SubOffice.objects.filter(pincode = pin)
        #         sub['sub'] = suboffice
        if isconn:
            near  = Connection.objects.get(email =e)
            pin = near.pincode
            suboffice = SubOffice.objects.filter(pincode = pin)
            sub = {}
            if suboffice:
                suboffice = SubOffice.objects.filter(pincode = pin)
                sub['sub'] = suboffice
            profile = Connection.objects.get(email =e)
            return render(request, 'customer/index.html',{'name':profile,'sub':suboffice})
        return render(request, 'customer/index.html')
    else:
        return redirect(index)

def newconnection(request):
    if request.session.has_key('user'):
        email = request.session['user']
        hasConnection = Connection.objects.filter(email = email)
        if hasConnection:
            info = Connection.objects.get(email = email)
            # print(info.photo.url)
            return render(request, 'customer/newconnection.html',{'msg':hasConnection,'myconn':info})
        else:
            info = Registration.objects.get(email = email)
            name = info.name
            email = info.email
            mobile = info.mobile
            dict = {'name':name,'email':email,'mobile':mobile}
            if request.method == "POST" and request.FILES['img']:
                name  = request.POST.get('name')
                email = request.POST.get('email')
                mobile = request.POST.get('mobile')
                gender = request.POST.get('gender')
                dob = request.POST.get('dob')
                fname = request.POST.get('fname')
                nationality = request.POST.get('nationality')
                add = request.POST.get('add')
                city = request.POST.get('city')
                type = request.POST.get('type')
                pincode = request.POST.get('pin')
                photo = request.FILES['img']   
                createConnection = Connection(name,email,mobile,gender,dob,fname,nationality,add,city,type,pincode,photo,conn_date=datetime.date.toordinal,status=Status(2))
                createConnection.save()
                return redirect(newconnection)
            return render(request, 'customer/newconnection.html', dict)
        pass
    else:
        return redirect(index)
    return render(request, 'customer/newconnection.html')


def logout(request):
    try:
        del request.session['user']
    except:
        pass
    return redirect(login)

def profile(request):
    if request.session.has_key('user'):
        cust  = request.session['customer']
        customer = Connection.objects.get(custno = cust)
        return render(request, 'customer/profile.html', {'name':customer})
    return redirect(index)


def profileupdate(request):
    if request.session.has_key('customer'):
        cust = request.session['customer']
        customer = Customer.objects.get(custno = cust)
        phone = request.POST.get("phone")
        custadd = request.POST.get("add")
        custcity = request.POST.get("city")
        pincode = request.POST.get("pincode")
        password = request.POST.get("password")
        customer.password = password
        customer.phone = phone
        customer.custadd = custadd
        customer.custcity = custcity
        customer.pincode = pincode
        customer.save(update_fields=['phone','custadd','custcity','pincode','password'])
        return redirect(profile)
    else:
        return redirect(index)
    
def booking(request):
    if request.session.has_key('user'):
        email = request.session['user']
        customer = Connection.objects.filter(email = email)
        if customer:
            checkPeding = Connection.objects.get(email=email)
            st = checkPeding.status
            # print(st)
            if st == Status(2):
                return render(request, 'customer/book.html', {'msg':"your Connection is Panding !!! You can not Book"})
            else:
                customer = Connection.objects.get(email = email)
                cytype = customer.type
                p = Price.objects.get(cylinderType=cytype)
                price = p.price
                bookingdate = date.today().strftime('%d/%m/%y')
                ddate = date.today() + datetime.timedelta(days=3)
                ddate = ddate.strftime('%d/%m/%y')
                # dict = {'customer':customer,'price':price, 'bookingdate':bookingdate,'name':customer,'ddate':ddate}
                if request.method == 'POST':
                    b_date = request.POST.get('booking')
                    d_date = request.POST.get('deli')
                    book = Booking(email=email, name=customer.name,b_date=b_date,d_date= d_date, ctype =cytype, price = price, status=Status(2))
                    book.save()
                    return redirect(booking)
                bookingtable = Booking.objects.filter(email=email)
                dict = {'books':bookingtable,'customer':customer,'price':price, 'bookingdate':bookingdate,'name':customer,'ddate':ddate}
                return render(request, 'customer/book.html', dict)
        else:
            return redirect(newconnection)
    return redirect(index)


def editorder(request , pk):
    context = {'id':pk}
    return render(request, 'customer/edit_order.html', context)